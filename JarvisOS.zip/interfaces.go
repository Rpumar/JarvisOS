package core

import "time"

// Este archivo agrupa las interfaces de las que depende Brain. Se separaron
// de brain.go para que ese archivo se concentre en la lógica de
// orquestación, no en definiciones de tipos. Es el mismo principio que ya
// se venía aplicando (Brain depende de abstracciones, no de paquetes
// concretos como ia/agents/memoria) llevado a un archivo propio.

// EjecutorComandos es la interfaz mínima que Brain necesita de Hands.
// *Hands ya la cumple sin ningún cambio: RunCommand y Hablar ya tienen
// exactamente esta firma.
type EjecutorComandos interface {
	RunCommand(cmd string) string
	Hablar(texto string) string
}

// TurnoConversacion representa un intercambio pasado con el respaldo de IA,
// para darle memoria de sesión a la conversación (que "¿y qué más hizo?"
// tenga sentido después de "¿quién fue Einstein?").
type TurnoConversacion struct {
	Usuario   string
	Asistente string
}

// ConectorIA es la interfaz mínima que Brain necesita para consultar un LLM
// externo como respaldo conversacional. Ahora recibe también el historial
// reciente de la conversación.
type ConectorIA interface {
	Disponible() bool
	Consultar(prompt string, historial []TurnoConversacion) (string, error)
}

// AgenteDeCodigo es la interfaz mínima que Brain necesita para el flujo de
// generación y confirmación de scripts (ver agents.CoderAgent).
type AgenteDeCodigo interface {
	Proponer(peticion string) (string, error)
	Confirmar() string
	Cancelar() string
	TienePropuestaPendiente() bool
}

// MemoriaPersistente es la interfaz mínima que Brain necesita para guardar
// hechos puntuales (nombre, ciudad, etc.), notas libres y recordatorios con
// hora entre reinicios. Devuelve []string ya formateadas en ObtenerNotas
// (no un tipo del paquete memoria) para que Brain no dependa de su
// representación interna.
type MemoriaPersistente interface {
	GuardarHecho(clave, valor string) error
	ObtenerHecho(clave string) (valor string, existe bool)
	AgregarNota(texto string) error
	ObtenerNotas() []string
	AgregarRecordatorio(texto string, momento time.Time) error
	ObtenerRecordatoriosPendientesTexto() []string
	CancelarRecordatorios(textoBusqueda string) (int, error)
}

// BrainOpciones agrupa las dependencias opcionales de Brain. Se usa en vez
// de seguir agregando parámetros posicionales a NewBrain cada vez que se
// suma una fase nueva (ya iba a ser el cuarto parámetro con Memoria). Todos
// los campos pueden quedar en su valor cero (nil): Brain simplemente no
// ofrece esa capacidad si no está configurada.
type BrainOpciones struct {
	IA      ConectorIA
	Coder   AgenteDeCodigo
	Memoria MemoriaPersistente
}
