package core

import (
	"fmt"
	"strings"
	"time"
)

// --- Memoria de sesión: resolución de pronombres ---

var frasesCerrarSinObjeto = []string{
	"ciérralo", "cierralo", "ciérrala", "cierrala", "cerrar eso", "cerralo",
}

var frasesRepetirBusquedaEnYoutube = []string{
	"lo mismo en youtube", "buscá lo mismo en youtube", "busca lo mismo en youtube", "eso mismo en youtube",
}

var frasesQueDijiste = []string{"qué dijiste", "que dijiste", "repetí eso", "repeti eso", "podés repetir", "podes repetir"}

// resolverPronombres reescribe comandos que dependen de la memoria de
// sesión ("cerralo", "lo mismo en youtube") a su forma explícita
// equivalente, usando la última app/búsqueda recordada. Si no hay nada
// recordado, o la frase no aplica, devuelve la entrada sin cambios (lo más
// probable es que termine en "no entendí", que es razonable si no hay
// contexto previo).
func (b *Brain) resolverPronombres(entrada string) string {
	for _, f := range frasesCerrarSinObjeto {
		if entrada == f && b.ultimaApp != "" {
			return "cerrar " + b.ultimaApp
		}
	}
	for _, f := range frasesRepetirBusquedaEnYoutube {
		if strings.Contains(entrada, f) && b.ultimaBusqueda != "" {
			return "buscar en youtube " + b.ultimaBusqueda
		}
	}
	return entrada
}

// actualizarMemoriaDeSesion guarda la última app abierta / última búsqueda
// para que resolverPronombres las pueda usar más adelante en la sesión.
func (b *Brain) actualizarMemoriaDeSesion(entrada string) {
	if strings.HasPrefix(entrada, "abrir ") {
		b.ultimaApp = strings.TrimSpace(strings.TrimPrefix(entrada, "abrir "))
		return
	}
	if strings.HasPrefix(entrada, "buscar en youtube ") {
		b.ultimaBusqueda = strings.TrimSpace(strings.TrimPrefix(entrada, "buscar en youtube "))
		return
	}
	if strings.HasPrefix(entrada, "buscar ") {
		b.ultimaBusqueda = strings.TrimSpace(strings.TrimPrefix(entrada, "buscar "))
	}
}

// --- Memoria persistente: recordar hechos, notas y recordatorios con hora ---

// prefijosRecordar cubre tanto "recordá que" (fase 2) como "recordame"/
// "avisame" (fase 3) para el caso SIN hora — con hora, extraerRecordatorio
// (recordatorios.go) se prueba primero y tiene prioridad.
var prefijosRecordar = []string{
	"recordá que ", "recorda que ", "acordate que ", "acuérdate que ",
	"recordame que ", "recordame ", "avisame que ", "avisame ",
}

var patronesNombre = []string{"me llamo ", "mi nombre es ", "llamame ", "llámame ", "decime "}
var patronesCiudad = []string{"vivo en ", "mi ciudad es "}
var patronesCumpleanos = []string{"mi cumpleaños es ", "cumplo años el "}
var patronesTrabajo = []string{"trabajo en ", "trabajo de ", "mi trabajo es "}

var frasesPreguntaNombre = []string{"cuál es mi nombre", "cual es mi nombre", "cómo me llamo", "como me llamo"}
var frasesPreguntaCiudad = []string{"dónde vivo", "donde vivo", "cuál es mi ciudad", "cual es mi ciudad"}
var frasesPreguntaCumpleanos = []string{"cuándo es mi cumpleaños", "cuando es mi cumpleaños", "cuál es mi cumpleaños"}
var frasesPreguntaTrabajo = []string{"dónde trabajo", "donde trabajo", "cuál es mi trabajo", "cual es mi trabajo"}
var frasesPreguntaNotas = []string{"qué recordás", "que recordas", "qué notas tenés", "que notas tenes", "qué me pediste recordar"}
var frasesPreguntaRecordatorios = []string{"qué recordatorios tengo", "que recordatorios tengo", "qué avisos tengo"}
var frasesCancelarTodos = []string{"cancelá todos los recordatorios", "cancela todos los recordatorios", "cancelá mis recordatorios", "cancela mis recordatorios"}
var prefijosCancelarRecordatorio = []string{
	"cancelá el recordatorio de ", "cancela el recordatorio de ",
	"cancelá los recordatorios de ", "cancela los recordatorios de ",
	"cancelá el recordatorio sobre ", "cancela el recordatorio sobre ",
}

// procesarMemoria maneja todos los comandos relacionados con memoria
// persistente y recordatorios. Devuelve (respuesta, true) si la entrada
// era efectivamente uno de estos comandos (aunque no haya memoria
// configurada: en ese caso responde explicando eso), o ("", false) si no
// aplica y Process debe seguir con el resto del enrutamiento.
func (b *Brain) procesarMemoria(entrada string) (string, bool) {
	// Timer (duración relativa, "timer de 5 minutos"): se prueba primero
	// porque comparte prefijos ("avisame en...") con el recordatorio con
	// hora absoluta más abajo, y son mutuamente excluyentes por diseño.
	if duracion, ok := extraerTimer(entrada); ok {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		momento := time.Now().Add(duracion)
		if err := b.mem.AgregarRecordatorio("¡Timer terminado!", momento); err != nil {
			return fmt.Sprintf("No pude iniciar el timer, señor: %v", err), true
		}
		return fmt.Sprintf("Timer de %s en marcha, señor.", duracion), true
	}

	// Recordatorio CON hora: se prueba antes que el "recordar" genérico,
	// porque "recordame X a las Y" también empieza con un prefijo de
	// recordar y, sin este orden, terminaría guardado como nota libre en
	// vez de programarse.
	if texto, momento, ok := extraerRecordatorio(entrada); ok {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		if err := b.mem.AgregarRecordatorio(texto, momento); err != nil {
			return fmt.Sprintf("No pude programar el recordatorio, señor: %v", err), true
		}
		return fmt.Sprintf("Anotado, señor. Le aviso a las %s.", momento.Format("15:04")), true
	}

	// Cancelar recordatorios: también antes del "recordar" genérico, para
	// que "cancelá el recordatorio de X" no se confunda con guardar una
	// nota nueva que empiece con "cancelá".
	if contieneAlguna(entrada, frasesCancelarTodos) {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		n, err := b.mem.CancelarRecordatorios("")
		if err != nil {
			return fmt.Sprintf("No pude cancelarlos, señor: %v", err), true
		}
		if n == 0 {
			return "No tenía ningún recordatorio pendiente, señor.", true
		}
		return fmt.Sprintf("Cancelé sus %d recordatorios, señor.", n), true
	}
	if busqueda, ok := primerPrefijoQueCoincide(entrada, prefijosCancelarRecordatorio); ok {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		n, err := b.mem.CancelarRecordatorios(busqueda)
		if err != nil {
			return fmt.Sprintf("No pude cancelarlo, señor: %v", err), true
		}
		if n == 0 {
			return fmt.Sprintf("No encontré ningún recordatorio pendiente sobre '%s', señor.", busqueda), true
		}
		return "Cancelado, señor.", true
	}

	if contenido, ok := extraerContenidoRecordar(entrada); ok {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		if clave, valor, esHecho := extraerHecho(contenido); esHecho {
			if err := b.mem.GuardarHecho(clave, valor); err != nil {
				return fmt.Sprintf("No pude guardarlo, señor: %v", err), true
			}
			return fmt.Sprintf("Anotado. Ya sé que su %s es %s.", clave, valor), true
		}
		if err := b.mem.AgregarNota(contenido); err != nil {
			return fmt.Sprintf("No pude guardar la nota, señor: %v", err), true
		}
		return "Anotado, señor.", true
	}

	if contieneAlguna(entrada, frasesPreguntaNombre) {
		return b.responderHecho("nombre", "Se llama %s, señor. ¿O acaso lo olvidó?", "Todavía no me dijo su nombre, señor.")
	}
	if contieneAlguna(entrada, frasesPreguntaCiudad) {
		return b.responderHecho("ciudad", "Vive en %s, según lo que me contó.", "No sé dónde vive, señor. Todavía no me lo dijo.")
	}
	if contieneAlguna(entrada, frasesPreguntaCumpleanos) {
		return b.responderHecho("cumpleaños", "Su cumpleaños es el %s, señor.", "No sé cuándo es su cumpleaños. Todavía no me lo dijo.")
	}
	if contieneAlguna(entrada, frasesPreguntaTrabajo) {
		return b.responderHecho("trabajo", "Trabaja en %s, según lo que me contó.", "No sé dónde trabaja, señor. Todavía no me lo dijo.")
	}

	if contieneAlguna(entrada, frasesPreguntaNotas) {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		notas := b.mem.ObtenerNotas()
		if len(notas) == 0 {
			return "No tengo ninguna nota guardada, señor.", true
		}
		fmt.Println("Notas guardadas:")
		for _, n := range notas {
			fmt.Println(" -", n)
		}
		return fmt.Sprintf("Tengo %d notas guardadas. La última: %s. Mire la consola para ver todas.", len(notas), notas[len(notas)-1]), true
	}

	if contieneAlguna(entrada, frasesPreguntaRecordatorios) {
		if b.mem == nil {
			return "No tengo memoria persistente configurada, señor.", true
		}
		pendientes := b.mem.ObtenerRecordatoriosPendientesTexto()
		if len(pendientes) == 0 {
			return "No tiene ningún recordatorio pendiente, señor.", true
		}
		fmt.Println("Recordatorios pendientes:")
		for _, p := range pendientes {
			fmt.Println(" -", p)
		}
		return fmt.Sprintf("Tiene %d recordatorios pendientes. Mire la consola para ver todos.", len(pendientes)), true
	}

	return "", false
}

// responderHecho centraliza el patrón repetido de "preguntar por un hecho
// guardado" (nombre, ciudad, cumpleaños, trabajo): mismo chequeo de
// memoria configurada, mismo formateo, solo cambia la clave y los textos.
func (b *Brain) responderHecho(clave, formatoConValor, mensajeSinValor string) (string, bool) {
	if b.mem == nil {
		return "No tengo memoria persistente configurada, señor.", true
	}
	if valor, existe := b.mem.ObtenerHecho(clave); existe {
		return fmt.Sprintf(formatoConValor, valor), true
	}
	return mensajeSinValor, true
}

// extraerContenidoRecordar detecta el prefijo "recordá que"/variantes y
// devuelve lo que sigue.
func extraerContenidoRecordar(entrada string) (contenido string, ok bool) {
	for _, p := range prefijosRecordar {
		if strings.HasPrefix(entrada, p) {
			return strings.TrimSpace(strings.TrimPrefix(entrada, p)), true
		}
	}
	return "", false
}

// extraerHecho detecta si contenido describe un hecho estructurado
// conocido (nombre, ciudad, cumpleaños, trabajo) y devuelve la
// clave/valor. Si no coincide con ningún patrón, esHecho es false y se
// guarda como nota libre en su lugar.
func extraerHecho(contenido string) (clave, valor string, esHecho bool) {
	if v, ok := primerPrefijoQueCoincide(contenido, patronesNombre); ok {
		return "nombre", v, true
	}
	if v, ok := primerPrefijoQueCoincide(contenido, patronesCiudad); ok {
		return "ciudad", v, true
	}
	if v, ok := primerPrefijoQueCoincide(contenido, patronesCumpleanos); ok {
		return "cumpleaños", v, true
	}
	if v, ok := primerPrefijoQueCoincide(contenido, patronesTrabajo); ok {
		return "trabajo", v, true
	}
	return "", "", false
}

func primerPrefijoQueCoincide(contenido string, prefijos []string) (resto string, ok bool) {
	for _, p := range prefijos {
		if strings.HasPrefix(contenido, p) {
			return strings.TrimSpace(strings.TrimPrefix(contenido, p)), true
		}
	}
	return "", false
}

func contieneAlguna(entrada string, frases []string) bool {
	for _, f := range frases {
		if strings.Contains(entrada, f) {
			return true
		}
	}
	return false
}
