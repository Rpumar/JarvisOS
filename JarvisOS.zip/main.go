package main

import (
	"fmt"
	"os"
	"strings"
	"time"

	"JarvisOS/agents"
	"JarvisOS/config"
	"JarvisOS/core"
	"JarvisOS/ia"
	"JarvisOS/memoria"
)

func main() {
	cfg := config.Load()

	fmt.Println("=================================")
	fmt.Printf(" JARVISOS v%s ACTIVADO\n", cfg.Version)
	fmt.Println(" El que maneja el total de la PC")
	fmt.Println(" Ahora con OÍDOS reales, MANOS y BOCA")
	fmt.Println("=================================")

	hands := core.NewHands()
	conectorIA := ia.NuevoConector(cfg.Timeout)
	coderAgent := agents.NewCoderAgent(conectorIA)

	almacen, err := memoria.NuevoAlmacen(cfg.RutaMemoria)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[ERROR FATAL] No se pudo inicializar la memoria persistente: %v\n", err)
		os.Exit(1)
	}

	brain := core.NewBrain(hands, core.BrainOpciones{
		IA:      conectorIA,
		Coder:   coderAgent,
		Memoria: almacen,
	})

	if conectorIA.Disponible() {
		fmt.Println("[IA] Conector activo (se detectó OPENAI_API_KEY): respaldo conversacional y CoderAgent habilitados.")
	} else {
		fmt.Println("[IA] Sin clave de API configurada: JarvisOS usará solo comandos locales (sin IA ni CoderAgent).")
	}
	fmt.Printf("[MEMORIA] Datos persistentes en: %s\n", cfg.RutaMemoria)

	oidos, err := core.NewEars(cfg.ModeloVoz)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[ERROR FATAL] No se pudo inicializar el micrófono: %v\n", err)
		fmt.Fprintf(os.Stderr, "Verifica que exista el modelo de voz en '%s' y que haya un micrófono conectado.\n", cfg.ModeloVoz)
		os.Exit(1)
	}
	defer oidos.Cerrar()

	fmt.Println("[JARVIS] Sistemas en línea.")

	// Vigía de recordatorios: corre en su propia goroutine, revisando cada
	// 30 segundos si hay algo pendiente y avisando por voz sin que se le
	// pida. Es la primera vez que dos partes del programa tocan la
	// memoria al mismo tiempo — por eso Almacen ahora tiene un mutex real.
	go vigilarRecordatorios(almacen, hands)

	for {
		fmt.Println("\n[OIDOS] Di 'Jarvis' para activarme...")
		comando, err := oidos.Escuchar()
		if err != nil {
			fmt.Printf("[ADVERTENCIA] %v\n", err)
			continue
		}

		if strings.Contains(comando, "jarvis") {
			hands.Hablar(brain.Saludar())
			time.Sleep(300 * time.Millisecond)

			fmt.Println("[OIDOS] Te escucho...")
			comando, err = oidos.Escuchar()
			if err != nil {
				fmt.Printf("[ADVERTENCIA] %v\n", err)
				continue
			}

			if comando != "" {
				respuesta := brain.Process(comando)
				if respuesta != "" {
					fmt.Printf("[JARVIS] %s\n", respuesta)
					hands.Hablar(respuesta)
				}
			}
		}

		if strings.Contains(comando, "apagar") {
			hands.Hablar(brain.Despedirse())
			break
		}
	}
}

// vigilarRecordatorios revisa periódicamente si hay recordatorios
// pendientes y los anuncia por voz sin que el usuario tenga que preguntar.
// Es la única parte de JarvisOS que le habla al usuario sin haber sido
// invocada primero. No tiene apagado prolijo (no escucha una señal de
// cancelación): al ser una goroutine, muere junto con el proceso cuando el
// programa termina, así que no hace falta más que eso para esta versión.
//
// FASE 4 (seguridad/robustez): un panic sin recuperar en una goroutine
// tumba TODO el proceso en Go, no solo esa goroutine — eso significaría
// que un error inesperado acá abajo se llevaría puesto también el
// micrófono y la voz. El recover() evita ese escenario: como mucho, este
// vigía en particular deja de revisar recordatorios, pero el resto de
// JarvisOS sigue funcionando.
func vigilarRecordatorios(almacen *memoria.Almacen, hands *core.Hands) {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("[ADVERTENCIA] El vigía de recordatorios se detuvo por un error inesperado: %v\n", r)
		}
	}()

	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		pendientes := almacen.RecordatoriosPendientes(time.Now())
		for _, r := range pendientes {
			hands.Hablar(fmt.Sprintf("Recordatorio, señor: %s", r.Texto))
			if err := almacen.MarcarCumplido(r.ID); err != nil {
				fmt.Printf("[ADVERTENCIA] No pude marcar el recordatorio como cumplido: %v\n", err)
			}
		}
	}
}
