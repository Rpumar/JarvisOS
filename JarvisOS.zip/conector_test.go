package ia

import (
	"testing"
	"time"
)

func TestDisponible(t *testing.T) {
	t.Run("sin clave configurada", func(t *testing.T) {
		t.Setenv("OPENAI_API_KEY", "")
		c := NuevoConector(5 * time.Second)
		if c.Disponible() {
			t.Error("Disponible() debería ser false sin OPENAI_API_KEY")
		}
	})

	t.Run("con clave configurada", func(t *testing.T) {
		t.Setenv("OPENAI_API_KEY", "sk-test-123")
		c := NuevoConector(5 * time.Second)
		if !c.Disponible() {
			t.Error("Disponible() debería ser true con OPENAI_API_KEY configurada")
		}
	})
}

func TestNuevoConector_TimeoutPorDefecto(t *testing.T) {
	c := NuevoConector(0)
	if c.httpClient.Timeout != 30*time.Second {
		t.Errorf("timeout por defecto = %v, esperaba 30s", c.httpClient.Timeout)
	}
}

func TestNuevoConector_RespetaTimeoutProvisto(t *testing.T) {
	c := NuevoConector(7 * time.Second)
	if c.httpClient.Timeout != 7*time.Second {
		t.Errorf("timeout = %v, esperaba 7s", c.httpClient.Timeout)
	}
}

func TestConsultar_SinClaveConfigurada(t *testing.T) {
	t.Setenv("OPENAI_API_KEY", "")
	c := NuevoConector(5 * time.Second)

	if _, err := c.Consultar("algo", nil); err == nil {
		t.Error("se esperaba un error sin clave de API configurada")
	}
}

func TestConsultarCodigo_SinClaveConfigurada(t *testing.T) {
	t.Setenv("OPENAI_API_KEY", "")
	c := NuevoConector(5 * time.Second)

	if _, _, err := c.ConsultarCodigo("algo"); err == nil {
		t.Error("se esperaba un error sin clave de API configurada")
	}
}

func TestParsearRespuestaCodigo(t *testing.T) {
	casos := []struct {
		nombre              string
		entrada             string
		codigoEsperado      string
		explicacionEsperada string
	}{
		{
			nombre:              "formato bien formado",
			entrada:             "CODIGO:\nGet-Date\nEXPLICACION:\nMuestra la fecha actual.",
			codigoEsperado:      "Get-Date",
			explicacionEsperada: "Muestra la fecha actual.",
		},
		{
			nombre:              "codigo vacío por petición riesgosa",
			entrada:             "CODIGO:\n\nEXPLICACION:\nNo genero scripts que borren carpetas del sistema.",
			codigoEsperado:      "",
			explicacionEsperada: "No genero scripts que borren carpetas del sistema.",
		},
		{
			nombre:              "sin marcadores: se descarta el código por seguridad",
			entrada:             "Claro, acá tenés un script: Get-Date",
			codigoEsperado:      "",
			explicacionEsperada: "Claro, acá tenés un script: Get-Date",
		},
		{
			nombre:         "marcadores en orden invertido: se descarta por seguridad",
			entrada:        "EXPLICACION:\nAlgo\nCODIGO:\nGet-Date",
			codigoEsperado: "",
		},
		{
			nombre:              "código multilínea",
			entrada:             "CODIGO:\nGet-ChildItem\nSort-Object Length\nEXPLICACION:\nLista archivos ordenados.",
			codigoEsperado:      "Get-ChildItem\nSort-Object Length",
			explicacionEsperada: "Lista archivos ordenados.",
		},
	}

	for _, c := range casos {
		t.Run(c.nombre, func(t *testing.T) {
			codigo, explicacion, err := parsearRespuestaCodigo(c.entrada)
			if err != nil {
				t.Fatalf("no se esperaba error: %v", err)
			}
			if codigo != c.codigoEsperado {
				t.Errorf("codigo = %q, esperaba %q", codigo, c.codigoEsperado)
			}
			if c.explicacionEsperada != "" && explicacion != c.explicacionEsperada {
				t.Errorf("explicacion = %q, esperaba %q", explicacion, c.explicacionEsperada)
			}
		})
	}
}
