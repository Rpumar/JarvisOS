package core

import (
	"fmt"
	"math/rand"
	"net"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// ComandoNoReconocido es el valor centinela que RunCommand devuelve cuando
// ningún comando local coincide. Brain lo usa para decidir si debe intentar
// una consulta de respaldo a la IA en vez de rendirse de inmediato.
const ComandoNoReconocido = "__NO_RECONOCIDO__"

// Códigos de tecla virtual de Windows para multimedia (winuser.h). Son
// valores estables desde Windows 2000. No existen como código nombrado en
// WScript.Shell.SendKeys (que solo cubre un teclado estándar de 101 teclas),
// por eso se simulan con keybd_event en vez de SendKeys.
const (
	vkVolumeMute     byte = 0xAD
	vkVolumeDown     byte = 0xAE
	vkVolumeUp       byte = 0xAF
	vkMediaNextTrack byte = 0xB0
	vkMediaPrevTrack byte = 0xB1
	vkMediaPlayPause byte = 0xB3
)

// Hands ejecuta acciones reales sobre Windows: abrir/cerrar apps, volumen,
// multimedia, navegador, sistema de archivos, capturas y voz (TTS).
type Hands struct{}

func NewHands() *Hands {
	return &Hands{}
}

// RunCommand interpreta cmd y ejecuta la acción correspondiente. Devuelve un
// texto listo para imprimir Y para hablar (por eso nunca incluye prefijos
// como "[MANOS]": eso se agrega solo al imprimir, no al hablar).
func (h *Hands) RunCommand(cmd string) string {
	cmd = strings.ToLower(strings.TrimSpace(cmd))

	// APPS
	switch {
	case strings.Contains(cmd, "abrir code"):
		return h.abrirApp("code")
	case strings.Contains(cmd, "abrir calculadora"):
		return h.abrirApp("calc")
	case strings.Contains(cmd, "abrir bloc"):
		return h.abrirApp("notepad")
	case strings.Contains(cmd, "abrir chrome"):
		return h.abrirApp("chrome")
	case strings.Contains(cmd, "abrir spotify"):
		return h.abrirApp("spotify:")
	case strings.Contains(cmd, "abrir word"):
		return h.abrirApp("winword")
	case strings.Contains(cmd, "abrir excel"):
		return h.abrirApp("excel")
	case strings.Contains(cmd, "abrir powerpoint"):
		return h.abrirApp("powerpnt")
	}

	// CERRAR APLICACIONES
	if strings.Contains(cmd, "cerrar ") {
		app := strings.TrimSpace(strings.Replace(cmd, "cerrar ", "", 1))
		return h.cerrarApp(app)
	}

	// VOLUMEN (mecanismo corregido esta ronda: ver enviarTeclaVirtual)
	switch {
	case strings.Contains(cmd, "subir volumen"):
		return h.volumen("up")
	case strings.Contains(cmd, "bajar volumen"):
		return h.volumen("down")
	case strings.Contains(cmd, "silencio"), strings.Contains(cmd, "mute"):
		return h.volumen("mute")
	}

	// MULTIMEDIA (nuevo)
	switch {
	case strings.Contains(cmd, "pausar"), strings.Contains(cmd, "reproducir"), cmd == "play":
		return h.controlMedia("play_pause")
	case strings.Contains(cmd, "siguiente canción"), strings.Contains(cmd, "siguiente cancion"):
		return h.controlMedia("next")
	case strings.Contains(cmd, "canción anterior"), strings.Contains(cmd, "cancion anterior"):
		return h.controlMedia("prev")
	}

	// INFO
	switch {
	case strings.Contains(cmd, "hora"):
		return h.decirHora()
	case strings.Contains(cmd, "fecha"), strings.Contains(cmd, "qué día es"):
		return h.decirFecha()
	case strings.Contains(cmd, "batería"), strings.Contains(cmd, "bateria"):
		return h.nivelBateria()
	case strings.Contains(cmd, "mi ip"):
		return h.obtenerIP()
	}

	// UTILIDADES (nuevo)
	switch {
	case strings.Contains(cmd, "chiste"):
		return h.contarChiste()
	case strings.Contains(cmd, "copiar "):
		texto := strings.TrimSpace(strings.Replace(cmd, "copiar ", "", 1))
		return h.copiarAlPortapapeles(texto)
	}

	// NAVEGADOR (el orden importa: las frases más específicas van primero,
	// porque "buscar en youtube"/"buscar en wikipedia" también contienen "buscar ")
	if strings.Contains(cmd, "buscar en youtube ") {
		consulta := strings.TrimSpace(strings.Replace(cmd, "buscar en youtube ", "", 1))
		return h.buscarEnYoutube(consulta)
	}
	if strings.Contains(cmd, "buscar en wikipedia ") {
		consulta := strings.TrimSpace(strings.Replace(cmd, "buscar en wikipedia ", "", 1))
		return h.buscarEnWikipedia(consulta)
	}
	if strings.Contains(cmd, "buscar ") {
		consulta := strings.TrimSpace(strings.Replace(cmd, "buscar ", "", 1))
		return h.buscarEnGoogle(consulta)
	}
	if strings.Contains(cmd, "ir a ") {
		sitio := strings.TrimSpace(strings.Replace(cmd, "ir a ", "", 1))
		return h.irASitio(sitio)
	}
	if strings.Contains(cmd, "andá a ") {
		sitio := strings.TrimSpace(strings.Replace(cmd, "andá a ", "", 1))
		return h.irASitio(sitio)
	}

	// SISTEMA
	switch {
	case strings.Contains(cmd, "bloquear pantalla"), strings.Contains(cmd, "bloquear pc"):
		return h.bloquearPantalla()
	case strings.Contains(cmd, "minimizar todo"), strings.Contains(cmd, "minimizar ventanas"):
		return h.minimizarTodo()
	case strings.Contains(cmd, "captura de pantalla"), strings.Contains(cmd, "capturar pantalla"):
		return h.capturarPantalla()
	}

	// ARCHIVOS Y SISTEMA OPERATIVO
	switch {
	case strings.Contains(cmd, "abrir descargas"):
		return h.abrirCarpeta("Downloads")
	case strings.Contains(cmd, "abrir escritorio"):
		return h.abrirCarpeta("Desktop")
	case strings.Contains(cmd, "abrir documentos"):
		return h.abrirCarpeta("Documents")
	case strings.Contains(cmd, "abrir papelera"):
		return h.abrirPapelera()
	case strings.Contains(cmd, "abrir configuración"), strings.Contains(cmd, "abrir configuracion"):
		return h.abrirConfiguracion()
	}

	// BOCA - REPETIR TEXTO
	if strings.Contains(cmd, "decir ") {
		mensaje := strings.TrimSpace(strings.Replace(cmd, "decir ", "", 1))
		if mensaje == "" {
			return "¿Qué desea que repita, señor?"
		}
		return mensaje
	}

	return ComandoNoReconocido
}

func (h *Hands) abrirApp(ruta string) string {
	if err := exec.Command("cmd", "/C", "start", "", ruta).Run(); err != nil {
		return fmt.Sprintf("No pude abrir eso, señor: %v", err)
	}
	return ConfirmacionGenerica()
}

// procesosProtegidos son procesos críticos de Windows que cerrarApp se
// niega a matar, sin excepción. Antes de esta revisión, cerrarApp le pasaba
// CUALQUIER nombre directo a "taskkill /F" — un "cerrar explorer" mal
// reconocido por voz (o pedido literalmente sin pensarlo) hubiera hecho
// exactamente lo mismo que pedir cerrar Chrome. Esto cierra ese hueco.
var procesosProtegidos = []string{
	"winlogon.exe", "csrss.exe", "services.exe", "lsass.exe", "smss.exe",
	"wininit.exe", "svchost.exe", "explorer.exe",
}

func esProcesoProtegido(proceso string) bool {
	procesoMin := strings.ToLower(proceso)
	for _, p := range procesosProtegidos {
		if procesoMin == p {
			return true
		}
	}
	return false
}

func (h *Hands) cerrarApp(app string) string {
	if app == "" {
		return "¿Qué aplicación desea que cierre, señor?"
	}
	proceso := app
	if !strings.HasSuffix(proceso, ".exe") {
		proceso += ".exe"
	}
	if esProcesoProtegido(proceso) {
		return fmt.Sprintf("No voy a cerrar %s, señor: es un proceso del sistema y podría dejar Windows inestable.", app)
	}
	if err := exec.Command("taskkill", "/IM", proceso, "/F").Run(); err != nil {
		return fmt.Sprintf("No pude cerrar %s. ¿Está abierta, señor?", app)
	}
	return fmt.Sprintf("%s cerrada, señor.", app)
}

// enviarTeclaVirtual simula la pulsación de una tecla virtual de Windows
// (volumen, multimedia) mediante keybd_event de user32.dll, llamado desde
// PowerShell vía Add-Type. CORRECCIÓN vs. la versión anterior: estas teclas
// no existen en el lenguaje de códigos de WScript.Shell.SendKeys (que solo
// cubre un teclado estándar de 101 teclas) — "{volume_up}" no es un código
// válido de SendKeys y no funcionaba. keybd_event con el código de tecla
// virtual real (verificado contra winuser.h) sí funciona.
func (h *Hands) enviarTeclaVirtual(codigoVK byte) error {
	ps := fmt.Sprintf(`Add-Type -TypeDefinition 'using System.Runtime.InteropServices; `+
		`public class TeclaVirtual { [DllImport("user32.dll")] `+
		`public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo); }'; `+
		`[TeclaVirtual]::keybd_event(%d, 0, 0, 0); Start-Sleep -Milliseconds 50; `+
		`[TeclaVirtual]::keybd_event(%d, 0, 2, 0)`, codigoVK, codigoVK)

	return exec.Command("powershell", "-Command", ps).Run()
}

func (h *Hands) volumen(accion string) string {
	var codigo byte
	var mensaje string
	switch accion {
	case "up":
		codigo, mensaje = vkVolumeUp, "Subiendo volumen, señor."
	case "down":
		codigo, mensaje = vkVolumeDown, "Bajando volumen, señor."
	case "mute":
		codigo, mensaje = vkVolumeMute, "Silenciando, señor."
	}
	if err := h.enviarTeclaVirtual(codigo); err != nil {
		return fmt.Sprintf("No pude ajustar el volumen: %v", err)
	}
	return mensaje
}

// controlMedia maneja play/pausa y cambio de pista (nuevo). VK_MEDIA_PLAY_PAUSE
// es una tecla de alternancia: no hay forma de saber desde acá si el
// reproductor queda en play o en pausa, por eso el mensaje es neutro.
func (h *Hands) controlMedia(accion string) string {
	var codigo byte
	var mensaje string
	switch accion {
	case "play_pause":
		codigo, mensaje = vkMediaPlayPause, "Listo, señor."
	case "next":
		codigo, mensaje = vkMediaNextTrack, "Siguiente canción, señor."
	case "prev":
		codigo, mensaje = vkMediaPrevTrack, "Canción anterior, señor."
	}
	if err := h.enviarTeclaVirtual(codigo); err != nil {
		return fmt.Sprintf("No pude controlar la reproducción: %v", err)
	}
	return mensaje
}

func (h *Hands) decirHora() string {
	return formatearHora(time.Now())
}

// formatearHora es la lógica pura de decirHora, separada para poder
// testearla sin depender del reloj real (se le inyecta el momento).
func formatearHora(ahora time.Time) string {
	return "Son las " + ahora.Format("15:04") + ", señor."
}

func (h *Hands) decirFecha() string {
	return formatearFecha(time.Now())
}

// formatearFecha es la lógica pura de decirFecha, separada para poder
// testearla sin depender del reloj real (se le inyecta el momento).
func formatearFecha(ahora time.Time) string {
	meses := [...]string{"enero", "febrero", "marzo", "abril", "mayo", "junio",
		"julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"}
	return fmt.Sprintf("Hoy es %d de %s de %d, señor.", ahora.Day(), meses[ahora.Month()-1], ahora.Year())
}

// nivelBateria consulta el nivel de batería vía WMI/CIM (nuevo).
func (h *Hands) nivelBateria() string {
	ps := "(Get-CimInstance -ClassName Win32_Battery | Select-Object -ExpandProperty EstimatedChargeRemaining)"
	salida, err := exec.Command("powershell", "-Command", ps).Output()
	if err != nil {
		return "No pude leer el nivel de batería, señor."
	}
	nivel := strings.TrimSpace(string(salida))
	if nivel == "" {
		return "No detecté ninguna batería, señor. ¿Es una PC de escritorio?"
	}
	return fmt.Sprintf("La batería está al %s por ciento, señor.", nivel)
}

// obtenerIP devuelve la IP local (LAN) sin depender de PowerShell (nuevo).
func (h *Hands) obtenerIP() string {
	direcciones, err := net.InterfaceAddrs()
	if err != nil {
		return fmt.Sprintf("No pude obtener la IP: %v", err)
	}
	for _, direccion := range direcciones {
		ipNet, ok := direccion.(*net.IPNet)
		if !ok || ipNet.IP.IsLoopback() {
			continue
		}
		if ip4 := ipNet.IP.To4(); ip4 != nil {
			return fmt.Sprintf("Su dirección IP local es %s, señor.", ip4.String())
		}
	}
	return "No pude encontrar una dirección IP local, señor."
}

var chistes = []string{
	"¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
	"¿Qué le dijo un semáforo a otro? No me mires que me estoy cambiando.",
	"¿Cómo se llama el campeón de buceo? Miguel Ángel.",
	"¿Por qué el libro de matemáticas está triste? Porque tiene muchos problemas.",
	"Un bit le dice a otro: ¿nos vamos de bytes esta noche?",
	"¿Cómo se despiden los químicos? Ácido un placer.",
}

// contarChiste devuelve un chiste al azar de una lista local (nuevo). Es
// local a propósito: funciona incluso sin OPENAI_API_KEY configurada.
func (h *Hands) contarChiste() string {
	return chistes[rand.Intn(len(chistes))]
}

// copiarAlPortapapeles copia texto al portapapeles de Windows (nuevo).
func (h *Hands) copiarAlPortapapeles(texto string) string {
	if texto == "" {
		return "¿Qué texto desea que copie, señor?"
	}
	textoEscapado := strings.ReplaceAll(texto, "'", "''")
	ps := fmt.Sprintf("Set-Clipboard -Value '%s'", textoEscapado)
	if err := exec.Command("powershell", "-Command", ps).Run(); err != nil {
		return fmt.Sprintf("No pude copiar el texto: %v", err)
	}
	return "Copiado al portapapeles, señor."
}

func (h *Hands) buscarEnGoogle(consulta string) string {
	if consulta == "" {
		return "¿Qué desea que busque, señor?"
	}
	destino := "https://www.google.com/search?q=" + url.QueryEscape(consulta)
	if err := exec.Command("cmd", "/C", "start", "", destino).Run(); err != nil {
		return fmt.Sprintf("No pude realizar la búsqueda: %v", err)
	}
	return fmt.Sprintf("Buscando %s en Google, señor.", consulta)
}

func (h *Hands) buscarEnYoutube(consulta string) string {
	if consulta == "" {
		return "¿Qué desea que busque en YouTube, señor?"
	}
	destino := "https://www.youtube.com/results?search_query=" + url.QueryEscape(consulta)
	if err := exec.Command("cmd", "/C", "start", "", destino).Run(); err != nil {
		return fmt.Sprintf("No pude abrir YouTube: %v", err)
	}
	return fmt.Sprintf("Buscando %s en YouTube, señor.", consulta)
}

// buscarEnWikipedia busca en la Wikipedia en español (nuevo).
func (h *Hands) buscarEnWikipedia(consulta string) string {
	if consulta == "" {
		return "¿Qué desea que busque en Wikipedia, señor?"
	}
	destino := "https://es.wikipedia.org/wiki/Special:Search?search=" + url.QueryEscape(consulta)
	if err := exec.Command("cmd", "/C", "start", "", destino).Run(); err != nil {
		return fmt.Sprintf("No pude abrir Wikipedia: %v", err)
	}
	return fmt.Sprintf("Buscando %s en Wikipedia, señor.", consulta)
}

// irASitio abre un sitio web directo (no una búsqueda). Completa ".com" y
// "https://" si el usuario no los dijo, para que "ir a youtube" alcance
// (nuevo).
func (h *Hands) irASitio(sitio string) string {
	if sitio == "" {
		return "¿A qué sitio quiere que vaya, señor?"
	}
	destino := sitio
	if !strings.Contains(destino, ".") {
		destino += ".com"
	}
	if !strings.HasPrefix(destino, "http://") && !strings.HasPrefix(destino, "https://") {
		destino = "https://" + destino
	}
	if err := exec.Command("cmd", "/C", "start", "", destino).Run(); err != nil {
		return fmt.Sprintf("No pude abrir %s: %v", sitio, err)
	}
	return fmt.Sprintf("Abriendo %s, señor.", sitio)
}

func (h *Hands) bloquearPantalla() string {
	if err := exec.Command("rundll32.exe", "user32.dll,LockWorkStation").Run(); err != nil {
		return fmt.Sprintf("No pude bloquear la pantalla: %v", err)
	}
	return "Pantalla bloqueada, señor."
}

func (h *Hands) minimizarTodo() string {
	ps := "(New-Object -ComObject Shell.Application).MinimizeAll()"
	if err := exec.Command("powershell", "-Command", ps).Run(); err != nil {
		return fmt.Sprintf("No pude minimizar las ventanas: %v", err)
	}
	return "Ventanas minimizadas, señor."
}

func (h *Hands) capturarPantalla() string {
	carpeta := filepath.Join(os.Getenv("USERPROFILE"), "Pictures")
	ruta := filepath.Join(carpeta, fmt.Sprintf("jarvis_captura_%d.png", time.Now().Unix()))

	ps := fmt.Sprintf(`Add-Type -AssemblyName System.Windows.Forms,System.Drawing;`+
		`$b=[System.Windows.Forms.SystemInformation]::VirtualScreen;`+
		`$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height;`+
		`$g=[System.Drawing.Graphics]::FromImage($bmp);`+
		`$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);`+
		`$bmp.Save('%s')`, ruta)

	if err := exec.Command("powershell", "-Command", ps).Run(); err != nil {
		return fmt.Sprintf("No pude tomar la captura: %v", err)
	}
	return fmt.Sprintf("Captura guardada en %s, señor.", ruta)
}

func (h *Hands) abrirCarpeta(nombre string) string {
	ruta := filepath.Join(os.Getenv("USERPROFILE"), nombre)
	// explorer.exe casi siempre devuelve código de salida distinto de cero
	// aunque la carpeta se abra correctamente, así que no tratamos err como fallo real.
	_ = exec.Command("explorer.exe", ruta).Run()
	return fmt.Sprintf("Abriendo %s, señor.", nombre)
}

// abrirPapelera abre la papelera de reciclaje (nuevo).
func (h *Hands) abrirPapelera() string {
	_ = exec.Command("explorer.exe", "shell:RecycleBinFolder").Run()
	return "Abriendo la papelera de reciclaje, señor."
}

func (h *Hands) abrirConfiguracion() string {
	if err := exec.Command("cmd", "/C", "start", "ms-settings:").Run(); err != nil {
		return fmt.Sprintf("No pude abrir la configuración: %v", err)
	}
	return "Abriendo configuración de Windows, señor."
}

// Hablar reproduce texto en voz alta usando la síntesis de voz nativa de
// Windows (SAPI) a través de PowerShell. No requiere ninguna dependencia
// externa de Go.
func (h *Hands) Hablar(texto string) string {
	texto = strings.TrimSpace(texto)
	if texto == "" {
		return ""
	}
	fmt.Printf("[JARVIS HABLANDO]: %s\n", texto)

	textoEscapado := strings.ReplaceAll(texto, "'", "''")
	ps := fmt.Sprintf(`Add-Type -AssemblyName System.Speech; `+
		`$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; `+
		`$speak.Speak('%s')`, textoEscapado)

	if err := exec.Command("powershell", "-Command", ps).Run(); err != nil {
		fmt.Printf("[ADVERTENCIA] No se pudo reproducir voz: %v\n", err)
	}
	return "Listo, señor."
}
