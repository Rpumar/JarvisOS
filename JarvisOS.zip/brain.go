package core

import (
	"fmt"
	"strings"
)

const maxHistorialIA = 5 // turnos recientes que se le mandan a la IA como contexto

// Brain es el orquestador central de JarvisOS: recibe el texto ya
// reconocido y decide, en orden, si es (1) una respuesta a una propuesta de
// CoderAgent pendiente, (2) ayuda, (3) un pronombre a resolver con memoria
// de sesión ("cerralo"), (4) un comando de memoria persistente
// ("recordá que..."), (5) una petición de generar código, (6) un comando
// local, o (7) algo para el respaldo conversacional de IA.
type Brain struct {
	hands EjecutorComandos
	ia    ConectorIA
	coder AgenteDeCodigo
	mem   MemoriaPersistente

	// Memoria de sesión: vive en RAM, se resetea al reiniciar el programa.
	ultimaApp      string
	ultimaBusqueda string
	ultimaRespuesta string
	historialIA    []TurnoConversacion
}

// NewBrain crea el orquestador. Todos los campos de opciones son opcionales
// (su valor cero es nil): Brain simplemente no ofrece esa capacidad si no
// está configurada.
func NewBrain(h EjecutorComandos, opciones BrainOpciones) *Brain {
	return &Brain{hands: h, ia: opciones.IA, coder: opciones.Coder, mem: opciones.Memoria}
}

// Process interpreta input y devuelve la respuesta final (para imprimir y
// hablar). La lógica de enrutamiento vive en procesarInterno; acá se le
// aplica la personalización de trato y se guarda como "última respuesta"
// para el comando "qué dijiste".
func (b *Brain) Process(input string) string {
	respuesta := b.personalizarRespuesta(b.procesarInterno(input))
	if respuesta != "" {
		b.ultimaRespuesta = respuesta
	}
	return respuesta
}

// Saludar devuelve un saludo de activación, personalizado con el nombre si
// se conoce. Pensado para que main.go lo llame en vez de core.Saludo()
// directamente, así el saludo también se beneficia de la Fase 3.
func (b *Brain) Saludar() string {
	return b.personalizarRespuesta(Saludo())
}

// Despedirse devuelve una frase de cierre, personalizada igual que Saludar.
func (b *Brain) Despedirse() string {
	return b.personalizarRespuesta(Despedida())
}

// personalizarRespuesta reemplaza "señor" por el nombre guardado, si hay
// uno. Se aplica en un solo lugar centralizado (acá) en vez de tocar cada
// una de las decenas de strings de hands.go/personalidad.go que dicen
// "señor" — más simple y con muchísimo menos riesgo de romper algo.
func (b *Brain) personalizarRespuesta(respuesta string) string {
	if respuesta == "" || b.mem == nil {
		return respuesta
	}
	nombre, existe := b.mem.ObtenerHecho("nombre")
	if !existe || nombre == "" {
		return respuesta
	}
	return strings.ReplaceAll(respuesta, "señor", nombre)
}

// procesarInterno contiene el enrutamiento real. Devuelve (1) una
// respuesta a una propuesta de CoderAgent pendiente, (2) ayuda, (3) un
// pronombre resuelto con memoria de sesión ("cerralo"), (4) un comando de
// memoria persistente ("recordá que...", recordatorios), (5) una petición
// de generar código, (6) un comando local, o (7) el respaldo conversacional
// de IA.
func (b *Brain) procesarInterno(input string) string {
	entrada := strings.ToLower(strings.TrimSpace(input))
	if entrada == "" {
		return ""
	}

	// 1. Propuesta de CoderAgent pendiente: todo se interpreta como
	// confirmar/cancelar hasta resolverla.
	if b.coder != nil && b.coder.TienePropuestaPendiente() {
		switch {
		case strings.Contains(entrada, "confirmar"), strings.Contains(entrada, "confirmo"),
			strings.Contains(entrada, "ejecutar"), strings.Contains(entrada, "dale"):
			return b.coder.Confirmar()
		case strings.Contains(entrada, "cancelar"), strings.Contains(entrada, "cancelo"):
			return b.coder.Cancelar()
		default:
			return "Tiene una propuesta de script esperando, señor. Diga 'confirmar' para ejecutarla o 'cancelar' para descartarla."
		}
	}

	// 2. Ayuda.
	if strings.Contains(entrada, "ayuda") {
		fmt.Println(textoAyuda)
		return "Puede pedirme que abra aplicaciones, busque en internet, le diga la hora, escriba scripts, recuerde cosas, y más. Mire la consola para ver todos los comandos, señor."
	}

	// 2.5. "Qué dijiste": repite la última respuesta de esta sesión, sin
	// pasar por el resto del enrutamiento ni contar como un comando nuevo.
	if contieneAlguna(entrada, frasesQueDijiste) {
		if b.ultimaRespuesta == "" {
			return "Todavía no dije nada en esta sesión, señor."
		}
		return b.ultimaRespuesta
	}

	// 3. Resolución de pronombres con memoria de sesión ("cerralo", "lo
	// mismo en youtube"). Si no aplica, entrada queda igual.
	entrada = b.resolverPronombres(entrada)

	// 4. Comandos de memoria persistente ("recordá que...", "recordame...
	// a las...", "cuál es mi nombre", etc.) — se resuelven antes que
	// CoderAgent/Hands porque no pertenecen a ninguno de los dos.
	if respuesta, atendido := b.procesarMemoria(entrada); atendido {
		return respuesta
	}

	// 5. Petición de generar código.
	if b.coder != nil && esPeticionDeCodigo(entrada) {
		respuesta, err := b.coder.Proponer(input)
		if err != nil {
			return fmt.Sprintf("No pude generar el script: %v", err)
		}
		return respuesta
	}

	// 6. Comando local. Antes de despachar, se actualiza la memoria de
	// sesión (última app / última búsqueda) para futuras referencias por
	// pronombre, incluso si la acción específica llegara a fallar del lado
	// de Hands: es una simplificación consciente, no vale la pena
	// encadenar el resultado real solo para este detalle.
	b.actualizarMemoriaDeSesion(entrada)

	respuesta := b.hands.RunCommand(entrada)
	if respuesta != ComandoNoReconocido {
		return respuesta
	}

	// 7. Respaldo conversacional de IA, con el historial reciente como contexto.
	if b.ia != nil && b.ia.Disponible() {
		respuestaIA, err := b.ia.Consultar(input, b.historialIA)
		if err == nil && respuestaIA != "" {
			b.historialIA = append(b.historialIA, TurnoConversacion{Usuario: input, Asistente: respuestaIA})
			if len(b.historialIA) > maxHistorialIA {
				b.historialIA = b.historialIA[len(b.historialIA)-maxHistorialIA:]
			}
			return respuestaIA
		}
	}

	return RespuestaConfusion()
}

// esPeticionDeCodigo detecta pedidos de generación de scripts con un
// chequeo simple: un verbo de creación + un sustantivo de código, ambos en
// la misma frase. Requerir los dos reduce falsos positivos (p. ej. "buscar
// script de python" no dispara esto, porque "buscar" no es un verbo de
// creación en esta lista).
func esPeticionDeCodigo(entrada string) bool {
	tieneVerbo := strings.Contains(entrada, "escribe") || strings.Contains(entrada, "escribime") ||
		strings.Contains(entrada, "crea") || strings.Contains(entrada, "generame") ||
		strings.Contains(entrada, "genera") || strings.Contains(entrada, "hazme") ||
		strings.Contains(entrada, "haceme")
	tieneSustantivo := strings.Contains(entrada, "script") || strings.Contains(entrada, "código") ||
		strings.Contains(entrada, "codigo")
	return tieneVerbo && tieneSustantivo
}

const textoAyuda = `
Comandos disponibles:
  jarvis                          -> actívame
  decir [texto]                   -> repito lo que digas
  qué dijiste                     -> repito mi última respuesta
  abrir chrome / spotify / code / calculadora / bloc / word / excel / powerpoint
  cerrar [app] / cerralo          -> "cerralo" cierra la última app abierta
  hora / fecha / batería / mi ip
  buscar [algo]                   -> busca en Google
  buscar en youtube [algo] / lo mismo en youtube (repite la última búsqueda)
  buscar en wikipedia [algo]
  ir a [sitio]                    -> abre un sitio directo, sin buscar
  subir volumen / bajar volumen / silencio
  pausar / reproducir             -> play o pausa de música
  siguiente canción / canción anterior
  copiar [texto]                  -> lo copia al portapapeles
  cuéntame un chiste
  bloquear pantalla
  minimizar todo
  captura de pantalla
  abrir descargas / escritorio / documentos / papelera / configuración
  recordá que [algo]              -> guarda una nota libre
  recordame [algo] a las [hora]   -> recordatorio con hora, te avisa solo
  poné un timer de [X] minutos/segundos/horas
  qué recordatorios tengo / cancelá el recordatorio de [algo] / cancelá todos los recordatorios
  llamame [nombre] / me llamo [nombre] -> así te voy a decir en vez de "señor"
  recordá que vivo en / mi cumpleaños es / trabajo en [algo]
  cuál es mi nombre / dónde vivo / cuándo es mi cumpleaños / dónde trabajo / qué recordás
  escribe un script que [tarea]   -> genera un script con IA (pide confirmación antes de ejecutar)
  confirmar / cancelar            -> solo cuando hay un script propuesto esperando
  apagar                          -> me apago
Si ningún comando coincide y hay una clave de IA configurada, te responderé con IA, con memoria de la conversación reciente.`
