package config

import (
	"os"
	"path/filepath"
	"time"
)

// Config centraliza los parámetros de configuración de JarvisOS.
type Config struct {
	AppName string
	Version string
	// RequireApproval queda reservado para futuras acciones sensibles.
	// NO controla la confirmación de CoderAgent antes de ejecutar código:
	// esa confirmación es obligatoria siempre, por diseño, y no se puede
	// desactivar poniendo este campo en false.
	RequireApproval bool
	Timeout         time.Duration // usado como timeout del cliente HTTP hacia la IA
	ModeloVoz       string        // carpeta del modelo Vosk para reconocimiento de voz
	RutaMemoria     string        // archivo JSON de memoria persistente (hechos + notas)
}

// Load devuelve la configuración por defecto de JarvisOS.
func Load() *Config {
	return &Config{
		AppName:         "JARVISOS",
		Version:         "0.13.0",
		RequireApproval: true,
		Timeout:         30 * time.Second,
		ModeloVoz:       "./modelo-voz-es",
		RutaMemoria:     filepath.Join(os.Getenv("USERPROFILE"), "JarvisOS-datos", "memoria.json"),
	}
}
