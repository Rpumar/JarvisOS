module JarvisOS

go 1.22

// NOTA: no fijamos versiones exactas a mano para no arriesgar un hash incorrecto.
// Ejecuta "go mod tidy" (con internet activo) y Go completará esta sección
// automáticamente con las versiones reales más recientes de:
//   - github.com/gordonklaus/portaudio  (captura de audio del micrófono)
//   - github.com/alphacep/vosk-api/go   (reconocimiento de voz offline, motor Vosk)
