// Package memoria guarda hechos puntuales (nombre, ciudad, etc.), notas
// libres y recordatorios con hora en un archivo JSON local, para que
// JarvisOS recuerde cosas entre reinicios.
//
// NOTA DE SEGURIDAD, deliberada y ya conversada: el archivo queda en texto
// plano, sin cifrar. Es una decisión consciente para esta versión, no un
// descuido — está bien para nombre/ciudad/notas cotidianas, pero este
// paquete NO debería usarse para guardar nada sensible (contraseñas, datos
// financieros, etc.). Si eso cambia, hay que cifrar el archivo antes.
//
// CAMBIO DE FASE 3: a partir de los recordatorios con hora, Almacen pasa a
// tener DOS consumidores concurrentes reales: el flujo normal de comandos
// (goroutine principal) y el vigía de recordatorios en segundo plano
// (main.go, otra goroutine). Antes de esto, un comentario en este archivo
// decía explícitamente que no hacía falta protección concurrente porque
// todo pasaba en una sola goroutine — eso dejó de ser cierto, así que se
// agregó un sync.Mutex real en vez de dejar el comentario viejo sin tocar.
package memoria

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type notaGuardada struct {
	Texto string    `json:"texto"`
	Fecha time.Time `json:"fecha"`
}

// Recordatorio es un aviso con hora programada. ID es time.Now().UnixNano()
// en el momento de crearlo, suficiente como identificador único dado el
// volumen de uso esperado (no miles por segundo).
type Recordatorio struct {
	ID       int64     `json:"id"`
	Texto    string    `json:"texto"`
	Momento  time.Time `json:"momento"`
	Cumplido bool      `json:"cumplido"`
}

type datos struct {
	Hechos        map[string]string `json:"hechos"`
	Notas         []notaGuardada    `json:"notas"`
	Recordatorios []Recordatorio    `json:"recordatorios"`
}

// Almacen es el punto de acceso a la memoria persistente. Seguro para uso
// concurrente: todos los métodos toman mu antes de tocar datos.
type Almacen struct {
	ruta  string
	mu    sync.Mutex
	datos datos
}

// NuevoAlmacen carga la memoria desde ruta si el archivo ya existe, o
// arranca vacío si es la primera vez (no es un error que no exista todavía).
func NuevoAlmacen(ruta string) (*Almacen, error) {
	a := &Almacen{ruta: ruta, datos: datos{Hechos: map[string]string{}}}

	contenido, err := os.ReadFile(ruta)
	if err != nil {
		if os.IsNotExist(err) {
			return a, nil
		}
		return nil, fmt.Errorf("no se pudo leer la memoria en '%s': %w", ruta, err)
	}

	if err := json.Unmarshal(contenido, &a.datos); err != nil {
		return nil, fmt.Errorf("la memoria en '%s' parece corrupta: %w", ruta, err)
	}
	if a.datos.Hechos == nil {
		a.datos.Hechos = map[string]string{}
	}
	return a, nil
}

// GuardarHecho guarda un par clave/valor (p. ej. "nombre" -> "Juan") y lo
// persiste de inmediato en disco.
func (a *Almacen) GuardarHecho(clave, valor string) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.datos.Hechos[clave] = valor
	return a.guardarSinLock()
}

// ObtenerHecho devuelve el valor guardado para clave, si existe.
func (a *Almacen) ObtenerHecho(clave string) (string, bool) {
	a.mu.Lock()
	defer a.mu.Unlock()
	valor, existe := a.datos.Hechos[clave]
	return valor, existe
}

// AgregarNota guarda una nota libre con la fecha actual y la persiste de inmediato.
func (a *Almacen) AgregarNota(texto string) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.datos.Notas = append(a.datos.Notas, notaGuardada{Texto: texto, Fecha: time.Now()})
	return a.guardarSinLock()
}

// ObtenerNotas devuelve todas las notas guardadas, ya formateadas como
// texto con su fecha (p. ej. "2026-07-22: tengo reunión el jueves").
func (a *Almacen) ObtenerNotas() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	resultado := make([]string, len(a.datos.Notas))
	for i, n := range a.datos.Notas {
		resultado[i] = fmt.Sprintf("%s: %s", n.Fecha.Format("2006-01-02"), n.Texto)
	}
	return resultado
}

// AgregarRecordatorio programa un aviso para momento y lo persiste de inmediato.
func (a *Almacen) AgregarRecordatorio(texto string, momento time.Time) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.datos.Recordatorios = append(a.datos.Recordatorios, Recordatorio{
		ID:      time.Now().UnixNano(),
		Texto:   texto,
		Momento: momento,
	})
	return a.guardarSinLock()
}

// RecordatoriosPendientes devuelve los recordatorios no cumplidos cuyo
// momento ya llegó (Momento <= ahora). Pensado para que el vigía de
// recordatorios en main.go lo llame periódicamente.
func (a *Almacen) RecordatoriosPendientes(ahora time.Time) []Recordatorio {
	a.mu.Lock()
	defer a.mu.Unlock()
	var pendientes []Recordatorio
	for _, r := range a.datos.Recordatorios {
		if !r.Cumplido && !r.Momento.After(ahora) {
			pendientes = append(pendientes, r)
		}
	}
	return pendientes
}

// MarcarCumplido marca un recordatorio como ya avisado, para no repetirlo.
func (a *Almacen) MarcarCumplido(id int64) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	for i := range a.datos.Recordatorios {
		if a.datos.Recordatorios[i].ID == id {
			a.datos.Recordatorios[i].Cumplido = true
			break
		}
	}
	return a.guardarSinLock()
}

// ObtenerRecordatoriosPendientesTexto devuelve TODOS los recordatorios no
// cumplidos (haya llegado su hora o no), formateados con su fecha/hora, a
// diferencia de RecordatoriosPendientes que solo devuelve los que ya
// deberían haber avisado. Pensado para "qué recordatorios tengo".
func (a *Almacen) ObtenerRecordatoriosPendientesTexto() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	var resultado []string
	for _, r := range a.datos.Recordatorios {
		if !r.Cumplido {
			resultado = append(resultado, fmt.Sprintf("%s (%s)", r.Texto, r.Momento.Format("2006-01-02 15:04")))
		}
	}
	return resultado
}

// CancelarRecordatorios marca como cumplidos (sin avisar) todos los
// recordatorios pendientes cuyo texto contiene textoBusqueda. Si
// textoBusqueda es "", cancela TODOS los pendientes. Devuelve cuántos se
// cancelaron.
func (a *Almacen) CancelarRecordatorios(textoBusqueda string) (int, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	busqueda := strings.ToLower(textoBusqueda)
	cancelados := 0
	for i := range a.datos.Recordatorios {
		if a.datos.Recordatorios[i].Cumplido {
			continue
		}
		if busqueda == "" || strings.Contains(strings.ToLower(a.datos.Recordatorios[i].Texto), busqueda) {
			a.datos.Recordatorios[i].Cumplido = true
			cancelados++
		}
	}
	if cancelados == 0 {
		return 0, nil
	}
	if err := a.guardarSinLock(); err != nil {
		return cancelados, err
	}
	return cancelados, nil
}

// guardarSinLock asume que el llamador ya tiene mu. No usar sin haber
// tomado el lock antes (sync.Mutex no es reentrante).
func (a *Almacen) guardarSinLock() error {
	if err := os.MkdirAll(filepath.Dir(a.ruta), 0o700); err != nil {
		return fmt.Errorf("no se pudo preparar la carpeta de memoria: %w", err)
	}
	contenido, err := json.MarshalIndent(a.datos, "", "  ")
	if err != nil {
		return fmt.Errorf("no se pudo serializar la memoria: %w", err)
	}
	return os.WriteFile(a.ruta, contenido, 0o600)
}
