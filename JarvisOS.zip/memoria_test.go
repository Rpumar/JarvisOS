package memoria

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestNuevoAlmacen_ArchivoInexistente_ArrancaVacio(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "no-existe", "memoria.json")

	a, err := NuevoAlmacen(ruta)

	if err != nil {
		t.Fatalf("no se esperaba error con archivo inexistente: %v", err)
	}
	if _, existe := a.ObtenerHecho("nombre"); existe {
		t.Error("no debería haber ningún hecho en un almacén recién creado")
	}
	if len(a.ObtenerNotas()) != 0 {
		t.Error("no debería haber ninguna nota en un almacén recién creado")
	}
}

func TestGuardarYObtenerHecho(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	if err := a.GuardarHecho("nombre", "Juan"); err != nil {
		t.Fatalf("no se esperaba error al guardar: %v", err)
	}

	valor, existe := a.ObtenerHecho("nombre")
	if !existe {
		t.Fatal("se esperaba que el hecho existiera")
	}
	if valor != "Juan" {
		t.Errorf("valor = %q, esperaba %q", valor, "Juan")
	}
}

func TestObtenerHecho_NoExistente(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	if _, existe := a.ObtenerHecho("ciudad"); existe {
		t.Error("no debería existir un hecho que nunca se guardó")
	}
}

func TestAgregarYObtenerNotas(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	if err := a.AgregarNota("tengo reunión el jueves"); err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}
	if err := a.AgregarNota("comprar pan"); err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}

	notas := a.ObtenerNotas()
	if len(notas) != 2 {
		t.Fatalf("len(notas) = %d, esperaba 2", len(notas))
	}
	if !strings.Contains(notas[0], "reunión") {
		t.Errorf("notas[0] = %q, esperaba que contuviera 'reunión'", notas[0])
	}
	if !strings.Contains(notas[1], "pan") {
		t.Errorf("notas[1] = %q, esperaba que contuviera 'pan'", notas[1])
	}
}

func TestPersistenciaRealEntreInstancias(t *testing.T) {
	// Este es el test que más importa acá: confirma que la memoria
	// realmente sobrevive a "reiniciar" (crear un Almacen nuevo apuntando
	// al mismo archivo), no solo que funciona en memoria durante un test.
	ruta := filepath.Join(t.TempDir(), "memoria.json")

	primero, err := NuevoAlmacen(ruta)
	if err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}
	if err := primero.GuardarHecho("nombre", "Ana"); err != nil {
		t.Fatalf("no se esperaba error al guardar: %v", err)
	}
	if err := primero.AgregarNota("primera nota"); err != nil {
		t.Fatalf("no se esperaba error al guardar: %v", err)
	}

	segundo, err := NuevoAlmacen(ruta)
	if err != nil {
		t.Fatalf("no se esperaba error al recargar: %v", err)
	}

	nombre, existe := segundo.ObtenerHecho("nombre")
	if !existe || nombre != "Ana" {
		t.Errorf("el hecho no sobrevivió al recargar: existe=%v, nombre=%q", existe, nombre)
	}
	if len(segundo.ObtenerNotas()) != 1 {
		t.Errorf("las notas no sobrevivieron al recargar: %v", segundo.ObtenerNotas())
	}
}

func TestArchivoCorrupto_DevuelveError(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	if err := os.WriteFile(ruta, []byte("esto no es JSON válido {{{"), 0o600); err != nil {
		t.Fatalf("no se pudo preparar el archivo de prueba: %v", err)
	}

	if _, err := NuevoAlmacen(ruta); err == nil {
		t.Error("se esperaba un error al cargar un archivo JSON corrupto")
	}
}

func TestAgregarRecordatorio_YObtenerlo(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)
	momento := time.Now().Add(1 * time.Hour)

	if err := a.AgregarRecordatorio("llamar a mamá", momento); err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}

	// Todavía no llegó la hora: no debería aparecer como pendiente.
	pendientes := a.RecordatoriosPendientes(time.Now())
	if len(pendientes) != 0 {
		t.Errorf("no debería haber pendientes antes de la hora programada, hay %d", len(pendientes))
	}

	// Consultando "ahora" como si ya hubiera pasado la hora, sí debería aparecer.
	pendientes = a.RecordatoriosPendientes(momento.Add(1 * time.Minute))
	if len(pendientes) != 1 {
		t.Fatalf("esperaba 1 pendiente después de la hora programada, hay %d", len(pendientes))
	}
	if pendientes[0].Texto != "llamar a mamá" {
		t.Errorf("texto = %q, esperaba %q", pendientes[0].Texto, "llamar a mamá")
	}
}

func TestMarcarCumplido_YaNoAparecePendiente(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)
	momento := time.Now().Add(-1 * time.Hour) // ya pasó

	_ = a.AgregarRecordatorio("comprar pan", momento)
	pendientes := a.RecordatoriosPendientes(time.Now())
	if len(pendientes) != 1 {
		t.Fatalf("esperaba 1 pendiente, hay %d", len(pendientes))
	}

	if err := a.MarcarCumplido(pendientes[0].ID); err != nil {
		t.Fatalf("no se esperaba error al marcar cumplido: %v", err)
	}

	pendientes = a.RecordatoriosPendientes(time.Now())
	if len(pendientes) != 0 {
		t.Errorf("no debería quedar pendiente después de marcarlo cumplido, hay %d", len(pendientes))
	}
}

func TestRecordatorios_SobrevivenAlRecargar(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	momento := time.Now().Add(2 * time.Hour)

	primero, _ := NuevoAlmacen(ruta)
	if err := primero.AgregarRecordatorio("reunión importante", momento); err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}

	segundo, err := NuevoAlmacen(ruta)
	if err != nil {
		t.Fatalf("no se esperaba error al recargar: %v", err)
	}
	pendientes := segundo.RecordatoriosPendientes(momento.Add(1 * time.Minute))
	if len(pendientes) != 1 || pendientes[0].Texto != "reunión importante" {
		t.Errorf("el recordatorio no sobrevivió al recargar: %+v", pendientes)
	}
}

func TestAlmacen_AccesoConcurrente_NoRompe(t *testing.T) {
	// No prueba timing, prueba que no explote ni se corrompa con acceso
	// concurrente real (correr con -race detecta condiciones de carrera si
	// el mutex faltara o estuviera mal puesto).
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(2)
		go func(n int) {
			defer wg.Done()
			_ = a.AgregarNota(fmt.Sprintf("nota %d", n))
		}(i)
		go func(n int) {
			defer wg.Done()
			_ = a.AgregarRecordatorio(fmt.Sprintf("recordatorio %d", n), time.Now())
		}(i)
	}
	wg.Wait()

	if len(a.ObtenerNotas()) != 20 {
		t.Errorf("se esperaban 20 notas tras el acceso concurrente, hay %d", len(a.ObtenerNotas()))
	}
}

func TestObtenerRecordatoriosPendientesTexto_IncluyeFuturosYNoSoloVencidos(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	_ = a.AgregarRecordatorio("cosa futura", time.Now().Add(2*time.Hour))
	_ = a.AgregarRecordatorio("cosa vencida", time.Now().Add(-1*time.Hour))

	textos := a.ObtenerRecordatoriosPendientesTexto()

	if len(textos) != 2 {
		t.Fatalf("esperaba 2 recordatorios pendientes (incluyendo el futuro), hay %d: %v", len(textos), textos)
	}
}

func TestObtenerRecordatoriosPendientesTexto_NoIncluyeCumplidos(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	_ = a.AgregarRecordatorio("ya avisado", time.Now().Add(-1*time.Hour))
	pendientes := a.RecordatoriosPendientes(time.Now())
	_ = a.MarcarCumplido(pendientes[0].ID)

	textos := a.ObtenerRecordatoriosPendientesTexto()
	if len(textos) != 0 {
		t.Errorf("un recordatorio cumplido no debería aparecer como pendiente, hay %d", len(textos))
	}
}

func TestCancelarRecordatorios_PorTexto(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	_ = a.AgregarRecordatorio("llamar a mamá", time.Now().Add(1*time.Hour))
	_ = a.AgregarRecordatorio("comprar pan", time.Now().Add(2*time.Hour))

	n, err := a.CancelarRecordatorios("mamá")

	if err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}
	if n != 1 {
		t.Fatalf("esperaba cancelar 1 recordatorio, canceló %d", n)
	}
	restantes := a.ObtenerRecordatoriosPendientesTexto()
	if len(restantes) != 1 {
		t.Errorf("esperaba 1 recordatorio restante, hay %d: %v", len(restantes), restantes)
	}
}

func TestCancelarRecordatorios_TodosConTextoVacio(t *testing.T) {
	ruta := filepath.Join(t.TempDir(), "memoria.json")
	a, _ := NuevoAlmacen(ruta)

	_ = a.AgregarRecordatorio("uno", time.Now().Add(1*time.Hour))
	_ = a.AgregarRecordatorio("dos", time.Now().Add(2*time.Hour))

	n, err := a.CancelarRecordatorios("")

	if err != nil {
		t.Fatalf("no se esperaba error: %v", err)
	}
	if n != 2 {
		t.Errorf("esperaba cancelar 2 recordatorios, canceló %d", n)
	}
	if len(a.ObtenerRecordatoriosPendientesTexto()) != 0 {
		t.Error("no debería quedar ningún recordatorio pendiente")
	}
}
