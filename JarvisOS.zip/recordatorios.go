package core

import (
	"regexp"
	"strconv"
	"strings"
	"time"
)

// Este archivo tiene una responsabilidad acotada a propósito: reconocer
// "recordame [algo] a las [hora]" y convertirlo en un texto + time.Time.
//
// LÍMITE HONESTO DE ALCANCE: solo entiende "a las H", "a las H:MM", y
// variantes con "de la mañana/tarde/noche". No entiende fechas ("el
// jueves", "mañana", "el 25 de julio") ni expresiones relativas ("en una
// hora", "en 20 minutos") — eso queda para una fase futura si hace falta.
// Si no reconoce el patrón, falla explícitamente en vez de adivinar mal:
// es preferible decir "no entendí la hora" a programar un aviso a una hora
// equivocada sin que el usuario se entere.

var patronHora = regexp.MustCompile(`a las (\d{1,2})(:(\d{2}))?\s*(de la (mañana|tarde|noche))?`)

var prefijosRecordatorio = []string{"recordame que ", "recordame ", "avisame que ", "avisame "}

// contenidoRecordatorio detecta un prefijo de recordatorio ("recordame...",
// "avisame...") y devuelve lo que sigue.
func contenidoRecordatorio(entrada string) (string, bool) {
	for _, p := range prefijosRecordatorio {
		if strings.HasPrefix(entrada, p) {
			return strings.TrimSpace(strings.TrimPrefix(entrada, p)), true
		}
	}
	return "", false
}

// parsearHora interpreta la porción de texto que matchea patronHora y
// devuelve la hora (0-23) y minuto. periodo desambigua "de la tarde/noche"
// (suma 12 si la hora es menor a 12) y "de la mañana" (12 se interpreta
// como medianoche).
func parsearHora(match []string) (hora, minuto int, ok bool) {
	if len(match) < 6 {
		return 0, 0, false
	}
	h, err := strconv.Atoi(match[1])
	if err != nil {
		return 0, 0, false
	}
	m := 0
	if match[3] != "" {
		m, err = strconv.Atoi(match[3])
		if err != nil {
			return 0, 0, false
		}
	}
	switch match[5] {
	case "tarde", "noche":
		if h < 12 {
			h += 12
		}
	case "mañana":
		if h == 12 {
			h = 0
		}
	}
	if h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, 0, false
	}
	return h, m, true
}

// proximaOcurrencia arma la próxima vez que ocurre hora:minuto a partir de
// ahora. Si esa hora ya pasó hoy, lo programa para mañana.
func proximaOcurrencia(hora, minuto int, ahora time.Time) time.Time {
	candidato := time.Date(ahora.Year(), ahora.Month(), ahora.Day(), hora, minuto, 0, 0, ahora.Location())
	if candidato.Before(ahora) {
		candidato = candidato.Add(24 * time.Hour)
	}
	return candidato
}

// extraerRecordatorio intenta interpretar entrada como un recordatorio con
// hora ("recordame llamar a mamá a las 5 de la tarde"). Devuelve el texto
// del recordatorio (sin la parte de la hora) y el momento programado. Si
// entrada no tiene el prefijo esperado, o no se pudo reconocer una hora
// válida, ok es false y el llamador debe tratar la entrada de otra forma
// (p. ej. como nota libre, si aplica).
func extraerRecordatorio(entrada string) (texto string, momento time.Time, ok bool) {
	contenido, tieneContenido := contenidoRecordatorio(entrada)
	if !tieneContenido {
		return "", time.Time{}, false
	}

	ubicacion := patronHora.FindStringSubmatchIndex(contenido)
	if ubicacion == nil {
		return "", time.Time{}, false
	}

	match := patronHora.FindStringSubmatch(contenido)
	hora, minuto, okHora := parsearHora(match)
	if !okHora {
		return "", time.Time{}, false
	}

	texto = strings.TrimSpace(contenido[:ubicacion[0]])
	if texto == "" {
		return "", time.Time{}, false
	}

	return texto, proximaOcurrencia(hora, minuto, time.Now()), true
}

// --- Timers: duración relativa, no hora absoluta ---

var patronDuracion = regexp.MustCompile(`(\d+)\s*(minutos?|segundos?|horas?)`)

var prefijosTimer = []string{
	"poné un timer de ", "pone un timer de ", "ponme un timer de ",
	"temporizador de ", "timer de ", "avisame en ",
}

// extraerTimer detecta "timer de X minutos/segundos/horas" (duración
// relativa a AHORA, no una hora del reloj como extraerRecordatorio) y
// devuelve la duración total. A diferencia de los recordatorios con hora,
// no lleva texto propio del usuario: el aviso siempre dice lo mismo
// ("¡Timer terminado!"), así que solo hace falta la duración.
func extraerTimer(entrada string) (duracion time.Duration, ok bool) {
	var contenido string
	var encontrado bool
	for _, p := range prefijosTimer {
		if strings.HasPrefix(entrada, p) {
			contenido = strings.TrimSpace(strings.TrimPrefix(entrada, p))
			encontrado = true
			break
		}
	}
	if !encontrado {
		return 0, false
	}

	match := patronDuracion.FindStringSubmatch(contenido)
	if match == nil {
		return 0, false
	}

	cantidad, err := strconv.Atoi(match[1])
	if err != nil || cantidad <= 0 {
		return 0, false
	}

	var unidad time.Duration
	switch {
	case strings.HasPrefix(match[2], "minuto"):
		unidad = time.Minute
	case strings.HasPrefix(match[2], "segundo"):
		unidad = time.Second
	case strings.HasPrefix(match[2], "hora"):
		unidad = time.Hour
	default:
		return 0, false
	}

	return time.Duration(cantidad) * unidad, true
}
