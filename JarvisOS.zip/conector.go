// Package ia provee un conector hacia un modelo de lenguaje externo, para
// que JarvisOS pueda responder cuando ningún comando local coincide.
//
// Se implementó contra la API de OpenAI (Chat Completions) porque es la más
// simple de integrar sin dependencias extra: solo net/http + encoding/json
// de la biblioteca estándar, sin SDK de terceros.
//
// Para cambiar a Gemini más adelante: la única pieza que hay que reescribir
// es este archivo (endpointOpenAI, peticionChat, respuestaChat y Consultar).
// El resto de JarvisOS (Brain, main.go) solo depende de la interfaz
// core.ConectorIA (Disponible() bool, Consultar(string) (string, error)),
// así que el cambio de proveedor no afecta a nada más.
package ia

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"

	"JarvisOS/core"
)

const endpointOpenAI = "https://api.openai.com/v1/chat/completions"

// Conector encapsula la configuración necesaria para consultar un LLM externo.
type Conector struct {
	apiKey     string
	modelo     string
	httpClient *http.Client
}

// NuevoConector crea un conector leyendo la clave de la variable de entorno
// OPENAI_API_KEY. Si no está configurada, el conector queda "no disponible"
// y JarvisOS sigue funcionando normalmente solo con comandos locales.
func NuevoConector(timeout time.Duration) *Conector {
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	return &Conector{
		apiKey:     os.Getenv("OPENAI_API_KEY"),
		modelo:     "gpt-4o-mini",
		httpClient: &http.Client{Timeout: timeout},
	}
}

// Disponible indica si hay una clave de API configurada.
func (c *Conector) Disponible() bool {
	return c.apiKey != ""
}

type mensajeChat struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type peticionChat struct {
	Model    string        `json:"model"`
	Messages []mensajeChat `json:"messages"`
}

type respuestaChat struct {
	Choices []struct {
		Message mensajeChat `json:"message"`
	} `json:"choices"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

// Consultar envía prompt al modelo configurado y devuelve su respuesta como
// texto plano, listo para hablar. Si no hay clave configurada o la petición
// falla, devuelve un error claro; Brain decide qué hacer con eso (rendirse
// con el mensaje genérico de "no entendí").
func (c *Conector) Consultar(prompt string, historial []core.TurnoConversacion) (string, error) {
	if !c.Disponible() {
		return "", fmt.Errorf("no hay clave de API configurada (variable de entorno OPENAI_API_KEY)")
	}

	mensajes := []mensajeChat{
		{Role: "system", Content: "Eres JARVIS, el asistente de voz personal de tu usuario. Personalidad: seguro de vos mismo, con ingenio seco y calidez, siempre competente -nunca payaso ni exagerado-. Tratás al usuario de 'señor' de forma cercana, no fría. Respondé siempre en español, en una o dos frases como máximo: tu respuesta se lee en voz alta, así que la brevedad importa más que el ingenio."},
	}
	for _, turno := range historial {
		mensajes = append(mensajes,
			mensajeChat{Role: "user", Content: turno.Usuario},
			mensajeChat{Role: "assistant", Content: turno.Asistente},
		)
	}
	mensajes = append(mensajes, mensajeChat{Role: "user", Content: prompt})

	cuerpo := peticionChat{
		Model:    c.modelo,
		Messages: mensajes,
	}

	datosJSON, err := json.Marshal(cuerpo)
	if err != nil {
		return "", fmt.Errorf("error al preparar la petición: %w", err)
	}

	peticion, err := http.NewRequest(http.MethodPost, endpointOpenAI, bytes.NewReader(datosJSON))
	if err != nil {
		return "", fmt.Errorf("error al construir la petición HTTP: %w", err)
	}
	peticion.Header.Set("Content-Type", "application/json")
	peticion.Header.Set("Authorization", "Bearer "+c.apiKey)

	resp, err := c.httpClient.Do(peticion)
	if err != nil {
		return "", fmt.Errorf("error al contactar la IA: %w", err)
	}
	defer resp.Body.Close()

	cuerpoResp, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error al leer la respuesta de la IA: %w", err)
	}

	var respuesta respuestaChat
	if err := json.Unmarshal(cuerpoResp, &respuesta); err != nil {
		return "", fmt.Errorf("error al interpretar la respuesta de la IA: %w", err)
	}

	if respuesta.Error != nil {
		return "", fmt.Errorf("la API de IA devolvió un error: %s", respuesta.Error.Message)
	}
	if len(respuesta.Choices) == 0 {
		return "", fmt.Errorf("la IA no devolvió ninguna respuesta")
	}

	return respuesta.Choices[0].Message.Content, nil
}

// promptSistemaCodigo es deliberadamente estricto: le pide al modelo que se
// niegue (CODIGO vacío) ante cualquier petición riesgosa o ambigua, en vez
// de intentar cumplirla de una forma "más segura" por su cuenta. Esta es la
// primera de varias capas de seguridad; agents.CoderAgent aplica las demás
// (bloqueo de patrones + confirmación humana obligatoria).
const promptSistemaCodigo = `Sos un generador de scripts de PowerShell para Windows, usado por un asistente de voz local llamado JarvisOS.
Reglas estrictas, sin excepciones:
- Generá ÚNICAMENTE scripts de PowerShell simples y seguros para tareas cotidianas de automatización (organizar archivos, leer información del sistema, tareas repetitivas, cálculos).
- NUNCA generes código que: formatee discos, borre carpetas amplias o del sistema, deshabilite seguridad o el firewall, modifique el registro de Windows, descargue o ejecute archivos de internet, apague o reinicie el equipo, o cree/modifique usuarios y permisos.
- Si la petición es peligrosa, ambigua, o pide algo fuera de este alcance, dejá CODIGO completamente vacío y explicá por qué en EXPLICACION.
Respondé ÚNICAMENTE en este formato exacto, sin texto adicional antes ni después:
CODIGO:
<el script de PowerShell, o nada si no corresponde>
EXPLICACION:
<una explicación breve en español, en una o dos frases, de qué hace el script o por qué no se generó>`

// ConsultarCodigo le pide al modelo un script de PowerShell para cumplir
// peticion, junto con una explicación breve. Esta función SOLO genera
// texto: nunca ejecuta nada. La ejecución (con confirmación humana
// obligatoria) es responsabilidad exclusiva de agents.CoderAgent.
func (c *Conector) ConsultarCodigo(peticion string) (codigo string, explicacion string, err error) {
	if !c.Disponible() {
		return "", "", fmt.Errorf("no hay clave de API configurada (variable de entorno OPENAI_API_KEY)")
	}

	cuerpo := peticionChat{
		Model: c.modelo,
		Messages: []mensajeChat{
			{Role: "system", Content: promptSistemaCodigo},
			{Role: "user", Content: peticion},
		},
	}

	datosJSON, err := json.Marshal(cuerpo)
	if err != nil {
		return "", "", fmt.Errorf("error al preparar la petición: %w", err)
	}

	peticionHTTP, err := http.NewRequest(http.MethodPost, endpointOpenAI, bytes.NewReader(datosJSON))
	if err != nil {
		return "", "", fmt.Errorf("error al construir la petición HTTP: %w", err)
	}
	peticionHTTP.Header.Set("Content-Type", "application/json")
	peticionHTTP.Header.Set("Authorization", "Bearer "+c.apiKey)

	resp, err := c.httpClient.Do(peticionHTTP)
	if err != nil {
		return "", "", fmt.Errorf("error al contactar la IA: %w", err)
	}
	defer resp.Body.Close()

	cuerpoResp, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", "", fmt.Errorf("error al leer la respuesta: %w", err)
	}

	var respuesta respuestaChat
	if err := json.Unmarshal(cuerpoResp, &respuesta); err != nil {
		return "", "", fmt.Errorf("error al interpretar la respuesta de la IA: %w", err)
	}
	if respuesta.Error != nil {
		return "", "", fmt.Errorf("la API de IA devolvió un error: %s", respuesta.Error.Message)
	}
	if len(respuesta.Choices) == 0 {
		return "", "", fmt.Errorf("la IA no devolvió ninguna respuesta")
	}

	return parsearRespuestaCodigo(respuesta.Choices[0].Message.Content)
}

// parsearRespuestaCodigo separa el texto del modelo en código y explicación
// buscando los marcadores "CODIGO:" y "EXPLICACION:". Si el modelo no
// respetó el formato pedido, se descarta el código por seguridad (mejor no
// proponer para ejecutar algo que no se pudo interpretar con confianza) y
// se devuelve todo el texto como explicación.
func parsearRespuestaCodigo(texto string) (codigo string, explicacion string, err error) {
	idxCodigo := strings.Index(texto, "CODIGO:")
	idxExplicacion := strings.Index(texto, "EXPLICACION:")

	if idxCodigo == -1 || idxExplicacion == -1 || idxExplicacion < idxCodigo {
		return "", strings.TrimSpace(texto), nil
	}

	codigo = strings.TrimSpace(texto[idxCodigo+len("CODIGO:") : idxExplicacion])
	explicacion = strings.TrimSpace(texto[idxExplicacion+len("EXPLICACION:"):])
	return codigo, explicacion, nil
}
